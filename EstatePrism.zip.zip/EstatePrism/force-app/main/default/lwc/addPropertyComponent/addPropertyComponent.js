import { LightningElement } from 'lwc';

export default class AddPropertyComponent extends LightningElement {}