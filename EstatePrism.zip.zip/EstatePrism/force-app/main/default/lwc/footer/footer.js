import { LightningElement, api,track} from 'lwc';
import logo from "@salesforce/resourceUrl/Eplogo";
import mail from "@salesforce/resourceUrl/emailIcon";
import Call from "@salesforce/resourceUrl/Callicon";
import Location from "@salesforce/resourceUrl/locationIcon";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import sendEmail from '@salesforce/apex/Subscribes.sendEmail';
export default class footer extends LightningElement {
    @track email = '';
    handleEmailChange(event) {
        this.email = event.target.value;
    }
    handleSend() {
        sendEmail({  email: this.email })
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Subscribed Successfully!',
                        variant: 'success'
                    })
                );
                this.resetForm();
            })
            .catch(error => {
                console.error('Error sending email: ', error);
                // Handle error, show error toast, etc.
            });
    }

    resetForm() {
        
       
        this.email = '';
        
    }


    @api companyLogoUrl = logo; // Provide URL to your company logo
   @api Call=Call;
   @api Mail=mail;
   @api location=Location;
 
    
}
