import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import sendEmail from '@salesforce/apex/ContactUsApexController.sendEmail';

export default class emailUs extends LightningElement {
    @track showEmailForm = false;
    @track name = '';
    @track email = '';
    @track message = '';

   

    handleEmailUs() {
        this.showEmailForm = true;
    }
    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handleMessageChange(event) {
        this.message = event.target.value;
    }

    handleSend() {
        sendEmail({ name: this.name, email: this.email, message: this.message })
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Your message has been sent!',
                        variant: 'success'
                    })
                );
                this.resetForm();
            })
            .catch(error => {
                console.error('Error sending email: ', error);
                // Handle error, show error toast, etc.
            });
    }

    resetForm() {
        this.showEmailForm = false;
        this.name = '';
        this.email = '';
        this.message = '';
    }
}
