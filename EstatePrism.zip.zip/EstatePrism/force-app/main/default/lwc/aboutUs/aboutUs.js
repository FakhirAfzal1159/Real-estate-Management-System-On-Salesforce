import { LightningElement } from 'lwc';
//import EpLogo from '@salesforce/resourceUrl/logo';

export default class AboutUs extends LightningElement {
   //  logoUrl=EpLogo ;
}